interface Behavior {
    jibby:Jibby
    performBehavior() : void
    onWash():void
    onEat():void
    onPet():void
}