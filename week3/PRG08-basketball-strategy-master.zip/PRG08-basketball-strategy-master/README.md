# PRG08-basketball-strategy

## Opdracht 1
Laat de basketball bewegen door het scherm zodat 'op aarde' de bal stuitert en 'op de maan' de bal tegen de randen van het scherm bots zonder zwaartekracht. 

## Opdracht 2 
Voeg het strategy pattern toe zodat het zelfde effect als bij opdracht 1 bereikt wordt.