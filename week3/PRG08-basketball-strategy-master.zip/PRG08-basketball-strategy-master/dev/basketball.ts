class BasketBall extends Ball{

    constructor(minWidth : number, maxWidth : number) {
        super(minWidth, maxWidth)
        
    }

    public update() : void {
    }
}

window.customElements.define("basketball-component", BasketBall)